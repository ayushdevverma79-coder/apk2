package com.smartattend.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    companion object { const val MATCH_THRESHOLD = 0.65f } // tune with your model and real faces

    private enum class Mode { NONE, ENROLL, VERIFY }

    private val prefs by lazy { getSharedPreferences("smartattend", Context.MODE_PRIVATE) }
    private val matcher by lazy { FaceMatcher(this) }
    private val exec = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()
        )
    }
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private lateinit var logView: TextView
    private lateinit var taskBox: LinearLayout
    private lateinit var nameField: EditText
    private var provider: ProcessCameraProvider? = null
    private var mode = Mode.NONE
    private var eyesOpen = false
    private var blinked = false
    private var handled = false

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else say("Camera permission is needed for face scan.")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun title(t: String) = TextView(this).apply { text = t; textSize = 18f; setPadding(0, dp(18), 0, dp(6)) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(16))
        }
        nameField = EditText(this).apply { hint = "Your name or roll number"; setText(prefs.getString("name", "")) }
        status = TextView(this).apply { text = "Enter your name, enroll your face once, then mark attendance." }
        preview = PreviewView(this).apply { visibility = View.GONE; layoutParams = LinearLayout.LayoutParams(-1, dp(320)) }
        logView = TextView(this)
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val taskField = EditText(this).apply { hint = "New task (faculty)" }

        root.addView(TextView(this).apply { text = "SmartAttend AI"; textSize = 26f })
        root.addView(nameField)
        root.addView(btn("Enroll my face (once)") { startFace(Mode.ENROLL) })
        root.addView(btn("Mark attendance with face") { startFace(Mode.VERIFY) })
        root.addView(btn("Mark attendance with fingerprint") { fingerprint() })
        root.addView(status); root.addView(preview)
        root.addView(title("Tasks"))
        root.addView(taskBox)
        root.addView(taskField)
        root.addView(btn("Add task") {
            val t = taskField.text.toString().replace("|", " ").trim()
            if (t.isNotEmpty()) { setTasks(tasks() + (t to false)); taskField.setText(""); refresh() }
        })
        root.addView(title("Attendance log")); root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun say(t: String) = runOnUiThread { status.text = t }
    private fun name() = nameField.text.toString().trim().also { prefs.edit().putString("name", it).apply() }

    // ---------- attendance log & tasks ----------
    private fun mark(method: String) {
        val line = "${SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date())} · ${name()} · $method"
        prefs.edit().putString("log", line + "\n" + prefs.getString("log", "")).apply()
        say("Attendance marked with $method.")
        runOnUiThread { refresh() }
    }
    private fun tasks(): List<Pair<String, Boolean>> {
        val raw = prefs.getString("tasks", "Solve 5 linked-list problems|0")!!
        return raw.lines().filter { it.contains("|") }.map { val p = it.split("|"); p[0] to (p[1] == "1") }
    }
    private fun setTasks(l: List<Pair<String, Boolean>>) =
        prefs.edit().putString("tasks", l.joinToString("\n") { "${it.first}|${if (it.second) 1 else 0}" }).apply()
    private fun refresh() {
        logView.text = prefs.getString("log", "")!!.ifBlank { "No attendance yet." }
        taskBox.removeAllViews()
        tasks().forEachIndexed { i, (t, done) ->
            taskBox.addView(CheckBox(this).apply {
                text = t; isChecked = done
                setOnCheckedChangeListener { _, c -> setTasks(tasks().toMutableList().also { it[i] = t to c }) }
            })
        }
    }

    // ---------- fingerprint (Android BiometricPrompt) ----------
    private fun fingerprint() {
        if (name().isEmpty()) return say("Enter your name first.")
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (can != BiometricManager.BIOMETRIC_SUCCESS)
            return say("No usable fingerprint (code $can). Add a fingerprint in Android Settings first.")
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Mark attendance").setSubtitle("Verify with your fingerprint")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel").build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = mark("Fingerprint")
            override fun onAuthenticationError(c: Int, e: CharSequence) = say("Fingerprint: $e")
            override fun onAuthenticationFailed() = say("Fingerprint not recognised. Try again.")
        }).authenticate(info)
    }

    // ---------- face (camera + ML Kit blink check + embedding match) ----------
    private fun startFace(m: Mode) {
        if (name().isEmpty()) return say("Enter your name first.")
        if (!matcher.ready) return say("Face model missing. Put mobilefacenet.tflite in app/src/main/assets (see README).")
        if (m == Mode.VERIFY && prefs.getString("emb", null) == null) return say("Enroll your face first.")
        mode = m; eyesOpen = false; blinked = false; handled = false
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get().also { provider = it }
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val ia = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            ia.setAnalyzer(exec) { analyze(it) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, ia)
            preview.visibility = View.VISIBLE
            say("Look at the camera and blink once.")
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || handled) { proxy.close(); return }
        val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        detector.process(img).addOnSuccessListener { faces ->
            if (handled || faces.size != 1) return@addOnSuccessListener
            val l = faces[0].leftEyeOpenProbability ?: 1f
            val r = faces[0].rightEyeOpenProbability ?: 1f
            if (l > 0.8f && r > 0.8f) {
                if (blinked) { handled = true; capture(proxy, faces[0]) } else eyesOpen = true
            } else if (l < 0.3f && r < 0.3f && eyesOpen) blinked = true
        }.addOnCompleteListener { proxy.close() }
    }

    private fun capture(proxy: ImageProxy, face: Face) {
        val raw = proxy.toBitmap()
        val up = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height,
            Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }, true)
        val b = face.boundingBox
        val x = b.left.coerceIn(0, up.width - 1)
        val y = b.top.coerceIn(0, up.height - 1)
        val w = b.width().coerceAtMost(up.width - x).coerceAtLeast(1)
        val h = b.height().coerceAtMost(up.height - y).coerceAtLeast(1)
        val emb = matcher.embed(Bitmap.createScaledBitmap(Bitmap.createBitmap(up, x, y, w, h), 112, 112, true))
        val m = mode; mode = Mode.NONE
        runOnUiThread { provider?.unbindAll(); preview.visibility = View.GONE }
        if (m == Mode.ENROLL) {
            prefs.edit().putString("emb", emb.joinToString(",")).apply()
            say("Face enrolled for ${name()}.")
        } else {
            val saved = prefs.getString("emb", "")!!.split(",").map { it.toFloat() }.toFloatArray()
            val sim = matcher.similarity(emb, saved)
            if (sim >= MATCH_THRESHOLD) mark("Face") else say("Face not recognised (score %.2f). Try again.".format(sim))
        }
    }
}
