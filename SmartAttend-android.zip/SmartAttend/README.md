# SmartAttend AI – Android app (face + fingerprint)

Local-only prototype: real fingerprint prompt, real camera face scan, attendance log and tasks stored on the phone.
It is NOT connected to the web prototype or any backend yet.

## Build the APK
1. Download a MobileFaceNet-style TFLite model (112x112x3 input, embedding output, e.g. 128/192 values)
   and save it as `app/src/main/assets/mobilefacenet.tflite`. Without it the face buttons show a "model missing" message.
2. Open this folder in Android Studio (Koala or newer, JDK 17), let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s). Or run on a phone with USB debugging.
   The debug APK appears in `app/build/outputs/apk/debug/`.

## How it works
- Fingerprint: Android BiometricPrompt. The app never sees the fingerprint; Android only confirms the phone's enrolled owner verified.
  It proves the person holding the phone, not which student they are, so each student must use their own phone.
- Face: CameraX front camera -> ML Kit face detection -> blink check (basic liveness) -> embedding with the TFLite model
  -> cosine similarity against the face enrolled on this phone. Tune `MATCH_THRESHOLD` in MainActivity.kt.

## Known limits (be upfront with judges)
- Not compiled or tested by the author of this source; expect to fix small build issues.
- A blink check stops a plain photo, not a video or mask. Production needs stronger liveness.
- Attendance is stored on the device only. A real system should send signed check-ins to the FastAPI backend.
- Biometric data is sensitive: get student consent and keep face data on-device or encrypted (India's DPDP Act).
